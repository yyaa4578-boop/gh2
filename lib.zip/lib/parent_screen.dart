import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:math';

class ParentScreen extends StatefulWidget {
  const ParentScreen({Key? key}) : super(key: key);

  @override
  State<ParentScreen> createState() => _ParentScreenState();
}

class _ParentScreenState extends State<ParentScreen> {
  String? _inviteCode;

  @override
  void initState() {
    super.initState();
    _generateAndSaveInviteCode();
  }

  Future<void> _generateAndSaveInviteCode() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    // توليد كود عشوائي بسيط (6 أرقام)
    String code = _generateCode();

    // حفظ الكود في ملف الأب في Firestore
    await FirebaseFirestore.instance.collection('parents').doc(user.uid).set({
      'inviteCode': code,
      'email': user.email,
    }, SetOptions(merge: true));

    setState(() {
      _inviteCode = code;
    });
  }

  String _generateCode() {
    final rand = Random();
    String code = '';
    for (int i = 0; i < 6; i++) {
      code += rand.nextInt(10).toString();
    }
    return code;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('شاشة المراقب'),
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: _inviteCode == null
            ? const CircularProgressIndicator()
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'شارك هذا الرمز مع ابنك للربط بينكما:',
                    style: TextStyle(fontSize: 18),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  SelectableText(
                    _inviteCode!,
                    style: const TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
