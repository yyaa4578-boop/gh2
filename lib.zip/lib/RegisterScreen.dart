import 'package:app/child_screen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';



class RegisterChildScreen extends StatefulWidget {
  const RegisterChildScreen({Key? key}) : super(key: key);

  @override
  State<RegisterChildScreen> createState() => _RegisterChildScreenState();
}

class _RegisterChildScreenState extends State<RegisterChildScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _inviteCodeController = TextEditingController();

  bool _isLoading = false;

  Future<void> _registerChild() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // إنشاء حساب الطفل
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      // التحقق من الكود الموجود
      String codeEntered = _inviteCodeController.text.trim();

      // البحث عن الأب صاحب هذا الكود
      QuerySnapshot query = await _firestore
          .collection('parents')
          .where('inviteCode', isEqualTo: codeEntered)
          .get();

      if (query.docs.isEmpty) {
        throw Exception('رمز الربط غير صحيح');
      }

      String parentId = query.docs.first.id;

      // حفظ بيانات الطفل مع الربط بالأب
      await _firestore.collection('children').doc(userCredential.user!.uid).set({
        'email': _emailController.text.trim(),
        'parentId': parentId,
      });

      // التوجه إلى شاشة الطفل
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const ChildScreen()),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تسجيل الطفل'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'كلمة المرور'),
            ),
            TextField(
              controller: _inviteCodeController,
              decoration: const InputDecoration(labelText: 'أدخل رمز الربط الخاص بالأب'),
            ),
            const SizedBox(height: 20),
            _isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _registerChild,
                    child: const Text('تسجيل'),
                  ),
          ],
        ),
      ),
    );
  }
}
