import 'package:app/LoginScreen.dart';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);
  
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    // تنفيذ التحقق بعد بناء الواجهة لتفادي مشاكل الـ context
    WidgetsBinding.instance.addPostFrameCallback((_) async {

    await Future.delayed(const Duration(seconds: 1)); 
 await _checkUserStatus();
      _checkUserStatus();
    });
  }

  Future<void> _checkUserStatus() async {
    User? user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      _goToLogin();
      return;
    }

    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final role = doc.data()?['role'];

      if (role == 'parent') {
        _goToParent();
      } else if (role == 'child') {
        _goToChild();
      } else {
        _goToLogin();  // إذا لم يوجد دور صالح
      }
    } catch (e) {
      // في حال خطأ جلب البيانات، اذهب لتسجيل الدخول
      _goToLogin();
    }
  }

  void _goToLogin() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  void _goToParent() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const ParentScreen()),
    );
  }

  void _goToChild() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const ChildScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,  // نفس لون الخلفية
      body: Center(
        child: Container(
          width: 180,
          height: 180,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [Colors.purple.shade900, Colors.pinkAccent.shade100],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.pinkAccent.shade100.withOpacity(0.6),
                spreadRadius: 5,
                blurRadius: 20,
                offset: const Offset(0, 0),
              ),
            ],
          ),
          child: const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              strokeWidth: 5,
            ),
          ),
        ),
      ),
    );
  }
}
