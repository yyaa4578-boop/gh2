import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChildScreen extends StatefulWidget {
  const ChildScreen({Key? key}) : super(key: key);

  @override
  State<ChildScreen> createState() => _ChildScreenState();
}

class _ChildScreenState extends State<ChildScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? _parentEmail;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchParentData();
  }

  Future<void> _fetchParentData() async {
    final user = _auth.currentUser;
    if (user == null) {
      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      // جلب بيانات الطفل من collection 'children'
      DocumentSnapshot childDoc =
          await _firestore.collection('children').doc(user.uid).get();

      if (!childDoc.exists) {
        throw Exception('بيانات الطفل غير موجودة');
      }

      String parentId = childDoc.get('parentId');

      // جلب بيانات الأب باستخدام parentId من collection 'parents'
      DocumentSnapshot parentDoc =
          await _firestore.collection('parents').doc(parentId).get();

      if (parentDoc.exists) {
        setState(() {
          _parentEmail = parentDoc.get('email') ?? 'لا يوجد بريد إلكتروني';
          _isLoading = false;
        });
      } else {
        setState(() {
          _parentEmail = 'بيانات الأب غير موجودة';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _parentEmail = 'حدث خطأ أثناء جلب بيانات الأب';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('شاشة الطفل'),
        backgroundColor: Colors.pink,
        centerTitle: true,
      ),
      body: Center(
        child: _isLoading
            ? const CircularProgressIndicator()
            : Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'هنا يظهر محتوى الطفل الخاص بالتطبيق',
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.pinkAccent,
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 30),
                    Text(
                      'البريد الإلكتروني للأب المرتبط:',
                      style: TextStyle(fontSize: 16, color: Colors.pink[700]),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      _parentEmail ?? 'غير مرتبط بأي أب',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.pink,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
